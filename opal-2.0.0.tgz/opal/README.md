# Opal Helm Chart

## Opal with managed R server

Opal deployment, with Rock spawner capability (on-demand R server management). Databases can be included in deployment (default is MongoDB). Databases and Opal backup cron jobs can be enabled.

## Databases

Default database is an internally managed MongoDB instance. It is also possible to configure an externally managed one. A single instance of MongoDB server can contain both the databases of the Opal and of the Opal IDs. The later one is optional.

Other databases (PostgreSQL for instance) can also be internally/externally managed. There will be one PostgreSQL server per database, i.e. the Opal data and the Opal IDs. The later one is optional.

Since Opal 6.0.0, Opal keeps its own configuration (projects, permissions, users, registered databases, DataSHIELD profiles...) in an embedded H2 database on its volume. It can be kept on a PostgreSQL server instead, internally or externally managed: see [Opal configuration on PostgreSQL](#opal-configuration-on-postgresql).

For each of these databases (internal/external Mongodb/PostgreSQL), a backup cron job can be enabled.

## Deployment

```
helm repo add obiba https://obiba.github.io/helm-charts
helm install myopal obiba/opal
```

### Upgrading

See [UPGRADE.md](UPGRADE.md) before upgrading an existing release. In particular, upgrading from chart version 1.2.1 or lower to 1.3.0 requires a one-time manual step.

## Values

### Global Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `namespace` | Kubernetes namespace | `default` |
| `nameOverride` | Override the name of the chart | `"opal"` |
| `global.storageClassName` | Storage class for PVCs (leave empty for default) | `""` |
| `global.existingSecret` | Global existing secret name for credentials (can be overridden per component) | `""` |

### Service Account

| Parameter | Description | Default |
|-----------|-------------|---------|
| `serviceAccount.name` | Service account name for Rock spawner | `rock-spawner-service-account` |

### MongoDB Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `useMongo` | Apply MongoDB configuration to Opal | `true` |
| `mongo.enabled` | Enable internally managed MongoDB | `true` |
| `mongo.name` | MongoDB StatefulSet name | `mongo` |
| `mongo.image` | MongoDB container image | `mongo:8.0` |
| `mongo.pvcSize` | Storage size for MongoDB PVC | `1Gi` |
| `mongo.backup.enabled` | Enable MongoDB backup cronjob | `false` |
| `mongo.backup.schedule` | Backup schedule (cron format) | `"0 1 * * *"` |
| `mongo.backup.pvcSize` | Storage size for backup PVC | `2Gi` |
| `mongo.backup.limit` | Number of backup archives to keep | `10` |
| `mongo.host` | MongoDB host (internal or external) | `mongo` |
| `mongo.port` | MongoDB port | `"27017"` |
| `mongo.database.data` | MongoDB database name for data | `mongo` |
| `mongo.database.ids` | MongoDB database name for IDs. If empty, the database of IDs is not enabled. | `ids` |
| `mongo.user` | MongoDB username | `root` |
| `mongo.password` | MongoDB password | `example` |
| `mongo.existingSecret` | Name of existing secret for MongoDB credentials (overrides global.existingSecret) | `""` |
| `mongo.existingSecretKeys.database.data` | Secret key for data database name | `MONGO_DATABASE` |
| `mongo.existingSecretKeys.database.ids` | Secret key for IDs database name | `MONGO_IDS` |
| `mongo.existingSecretKeys.user` | Secret key for username | `MONGO_USER` |
| `mongo.existingSecretKeys.password` | Secret key for password | `MONGO_PASSWORD` |
| `mongo.service.type` | Service type (`ClusterIP`, `NodePort`, `LoadBalancer`) | `ClusterIP` |
| `mongo.service.annotations` | Service annotations | `{}` |
| `mongo.podSecurityContext` | Pod security context | `{}` |
| `mongo.securityContext` | Container security context | `{}` |
| `mongo.priorityClassName` | Priority class name for scheduling | `""` |
| `mongo.nodeSelector` | Node selector for pod assignment | `{}` |
| `mongo.affinity` | Affinity rules for scheduling | `{}` |
| `mongo.tolerations` | Tolerations for scheduling | `[]` |

### PostgreSQL Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `usePostgres.config` | Keep Opal's own configuration on PostgreSQL instead of the embedded H2 database (Opal 6.0.0 and later). Decide before the first start, see the [example](#opal-configuration-on-postgresql). | `false` |
| `usePostgres.data` | Apply PostgreSQL data configuration to Opal | `false` |
| `usePostgres.ids` | Apply PostgreSQL IDs configuration to Opal | `false` |

#### PostgreSQL Configuration Database

| Parameter | Description | Default |
|-----------|-------------|---------|
| `postgres.config.enabled` | Enable internally managed PostgreSQL for Opal's configuration | `false` |
| `postgres.config.name` | PostgreSQL StatefulSet name | `postgres-config` |
| `postgres.config.image` | PostgreSQL container image | `postgres:17-alpine` |
| `postgres.config.pvcSize` | Storage size for PostgreSQL PVC | `1Gi` |
| `postgres.config.backup.enabled` | Enable PostgreSQL backup cronjob | `false` |
| `postgres.config.backup.schedule` | Backup schedule (cron format) | `"0 2 * * *"` |
| `postgres.config.backup.pvcSize` | Storage size for backup PVC | `2Gi` |
| `postgres.config.backup.limit` | Number of backup archives to keep | `10` |
| `postgres.config.host` | PostgreSQL host (internal or external) | `postgres-config` |
| `postgres.config.port` | PostgreSQL port | `"5432"` |
| `postgres.config.database` | PostgreSQL database name: an existing, empty database, Opal creates the schema itself | `opal_config` |
| `postgres.config.user` | PostgreSQL username | `opal` |
| `postgres.config.password` | PostgreSQL password (required: the chart refuses to render without one) | `example` |
| `postgres.config.existingSecret` | Name of existing secret for PostgreSQL credentials (overrides global.existingSecret) | `""` |
| `postgres.config.existingSecretKeys.database` | Secret key for database name | `POSTGRESCONFIG_DATABASE` |
| `postgres.config.existingSecretKeys.user` | Secret key for username | `POSTGRESCONFIG_USER` |
| `postgres.config.existingSecretKeys.password` | Secret key for password | `POSTGRESCONFIG_PASSWORD` |
| `postgres.config.service.type` | Service type (`ClusterIP`, `NodePort`, `LoadBalancer`) | `ClusterIP` |
| `postgres.config.service.annotations` | Service annotations | `{}` |
| `postgres.config.podSecurityContext` | Pod security context | `{}` |
| `postgres.config.securityContext` | Container security context | `{}` |
| `postgres.config.priorityClassName` | Priority class name for scheduling | `""` |
| `postgres.config.nodeSelector` | Node selector for pod assignment | `{}` |
| `postgres.config.affinity` | Affinity rules for scheduling | `{}` |
| `postgres.config.tolerations` | Tolerations for scheduling | `[]` |

#### PostgreSQL Data Database

| Parameter | Description | Default |
|-----------|-------------|---------|
| `postgres.data.enabled` | Enable internally managed PostgreSQL for data | `false` |
| `postgres.data.name` | PostgreSQL StatefulSet name | `postgres-data` |
| `postgres.data.image` | PostgreSQL container image | `postgres:17-alpine` |
| `postgres.data.pvcSize` | Storage size for PostgreSQL PVC | `1Gi` |
| `postgres.data.backup.enabled` | Enable PostgreSQL backup cronjob | `false` |
| `postgres.data.backup.schedule` | Backup schedule (cron format) | `"0 2 * * *"` |
| `postgres.data.backup.pvcSize` | Storage size for backup PVC | `2Gi` |
| `postgres.data.backup.limit` | Number of backup archives to keep | `10` |
| `postgres.data.host` | PostgreSQL host (internal or external) | `postgres-data` |
| `postgres.data.port` | PostgreSQL port | `"5432"` |
| `postgres.data.database` | PostgreSQL database name | `postgres` |
| `postgres.data.user` | PostgreSQL username | `postgres` |
| `postgres.data.password` | PostgreSQL password | `example` |
| `postgres.data.existingSecret` | Name of existing secret for PostgreSQL credentials (overrides global.existingSecret) | `""` |
| `postgres.data.existingSecretKeys.database` | Secret key for database name | `POSTGRESDATA_DATABASE` |
| `postgres.data.existingSecretKeys.user` | Secret key for username | `POSTGRESDATA_USER` |
| `postgres.data.existingSecretKeys.password` | Secret key for password | `POSTGRESDATA_PASSWORD` |
| `postgres.data.service.type` | Service type (`ClusterIP`, `NodePort`, `LoadBalancer`) | `ClusterIP` |
| `postgres.data.service.annotations` | Service annotations | `{}` |
| `postgres.data.podSecurityContext` | Pod security context | `{}` |
| `postgres.data.securityContext` | Container security context | `{}` |
| `postgres.data.priorityClassName` | Priority class name for scheduling | `""` |
| `postgres.data.nodeSelector` | Node selector for pod assignment | `{}` |
| `postgres.data.affinity` | Affinity rules for scheduling | `{}` |
| `postgres.data.tolerations` | Tolerations for scheduling | `[]` |

#### PostgreSQL IDs Database

| Parameter | Description | Default |
|-----------|-------------|---------|
| `postgres.ids.enabled` | Enable internally managed PostgreSQL for IDs | `false` |
| `postgres.ids.name` | PostgreSQL StatefulSet name | `postgres-ids` |
| `postgres.ids.image` | PostgreSQL container image | `postgres:17-alpine` |
| `postgres.ids.pvcSize` | Storage size for PostgreSQL PVC | `1Gi` |
| `postgres.ids.backup.enabled` | Enable PostgreSQL backup cronjob | `false` |
| `postgres.ids.backup.schedule` | Backup schedule (cron format) | `"0 2 * * *"` |
| `postgres.ids.backup.pvcSize` | Storage size for backup PVC | `2Gi` |
| `postgres.ids.backup.limit` | Number of backup archives to keep | `10` |
| `postgres.ids.host` | PostgreSQL host (internal or external) | `postgres-ids` |
| `postgres.ids.port` | PostgreSQL port | `"5432"` |
| `postgres.ids.database` | PostgreSQL database name | `postgres` |
| `postgres.ids.user` | PostgreSQL username | `postgres` |
| `postgres.ids.password` | PostgreSQL password | `example` |
| `postgres.ids.existingSecret` | Name of existing secret for PostgreSQL credentials (overrides global.existingSecret) | `""` |
| `postgres.ids.existingSecretKeys.database` | Secret key for database name | `POSTGRESIDS_DATABASE` |
| `postgres.ids.existingSecretKeys.user` | Secret key for username | `POSTGRESIDS_USER` |
| `postgres.ids.existingSecretKeys.password` | Secret key for password | `POSTGRESIDS_PASSWORD` |
| `postgres.ids.service.type` | Service type (`ClusterIP`, `NodePort`, `LoadBalancer`) | `ClusterIP` |
| `postgres.ids.service.annotations` | Service annotations | `{}` |
| `postgres.ids.podSecurityContext` | Pod security context | `{}` |
| `postgres.ids.securityContext` | Container security context | `{}` |
| `postgres.ids.priorityClassName` | Priority class name for scheduling | `""` |
| `postgres.ids.nodeSelector` | Node selector for pod assignment | `{}` |
| `postgres.ids.affinity` | Affinity rules for scheduling | `{}` |
| `postgres.ids.tolerations` | Tolerations for scheduling | `[]` |

### Opal Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `opal.image` | Opal container image | `obiba/opal:6.0` |
| `opal.imagePullPolicy` | Image pull policy | `Always` |
| `opal.pvcSize` | Storage size for Opal PVC | `1Gi` |
| `opal.javaOpts` | Java options for Opal | `"-Xms1G -Xmx2G -XX:+UseG1GC"` |
| `opal.extraEnv` | Extra environment variables for the Opal container (list of env entries) | `[]` |
| `opal.envFrom` | Extra environment sources for the Opal container (list of envFrom entries) | `[]` |
| `opal.backup.enabled` | Enable Opal files backup cronjob | `false` |
| `opal.backup.schedule` | Backup schedule (cron format) | `"0 3 * * *"` |
| `opal.backup.pvcSize` | Storage size for backup PVC | `2Gi` |
| `opal.backup.limit` | Number of backup archives to keep | `10` |
| `opal.service.type` | Service type (`ClusterIP`, `NodePort`, `LoadBalancer`) | `ClusterIP` |
| `opal.service.annotations` | Service annotations | `{}` |
| `opal.podSecurityContext` | Pod security context | `{}` |
| `opal.securityContext` | Container security context | `{}` |
| `opal.priorityClassName` | Priority class name for pod scheduling | `""` |
| `opal.nodeSelector` | Node selector for pod assignment | `{}` |
| `opal.affinity` | Affinity rules for scheduling | `{}` |
| `opal.tolerations` | Tolerations for scheduling | `[]` |

#### Opal Admin Password

| Parameter | Description | Default |
|-----------|-------------|---------|
| `opal.adminPassword.password` | Opal administrator password | `password` |
| `opal.adminPassword.existingSecret` | Name of existing secret for admin password (overrides global.existingSecret) | `""` |
| `opal.adminPassword.secretKey` | Secret key for admin password | `OPAL_ADMINISTRATOR_PASSWORD` |

#### OpenTelemetry

Opal 6.0.0 and later export the logs, the DataSHIELD session traces and the DataSHIELD metrics over OTLP. Setting an endpoint turns on all three; left disabled, no `OTEL_` variable is set and Opal builds no SDK. See the [example](#exporting-to-opentelemetry) below.

| Parameter | Description | Default |
|-----------|-------------|---------|
| `opal.otel.enabled` | Enable the OpenTelemetry export | `false` |
| `opal.otel.endpoint` | OTLP/HTTP endpoint of the collector (http/protobuf, port 4318 on a standard collector) | `"http://otel-collector:4318"` |
| `opal.otel.serviceName` | Name reported to the backend | `"opal"` |
| `opal.otel.resourceAttributes` | Extra resource attributes, e.g. `deployment.environment=production` | `""` |
| `opal.otel.metricExportInterval` | Metrics export interval in milliseconds (SDK default 60000) | `""` |
| `opal.otel.headers` | Headers sent with every request; use `existingSecret` for a token | `""` |
| `opal.otel.existingSecret` | Existing secret holding the headers (not defaulted from `global.existingSecret`) | `""` |
| `opal.otel.existingSecretKeys.headers` | Secret key for the headers | `OTEL_EXPORTER_OTLP_HEADERS` |
| `opal.otel.tls.existingSecret` | Existing secret with the collector's TLS material, mounted as files | `""` |
| `opal.otel.tls.existingSecretKeys.ca` | Secret key of the trusted CA certificate | `ca.crt` |
| `opal.otel.tls.existingSecretKeys.clientCertificate` | Secret key of the client certificate, for mTLS | `""` |
| `opal.otel.tls.existingSecretKeys.clientKey` | Secret key of the client key, for mTLS | `""` |

#### Opal Pod Resources

| Parameter | Description | Default |
|-----------|-------------|---------|
| `opal.resources.requests.memory` | Memory request | `1Gi` |
| `opal.resources.requests.cpu` | CPU request | `"1"` |
| `opal.resources.limits.memory` | Memory limit | `2Gi` |
| `opal.resources.limits.cpu` | CPU limit | `"2"` |

#### Rock (R Server) Pods Configuration

This section declares the default Rock server pods specifications.

| Parameter | Description | Default |
|-----------|-------------|---------|
| `opal.rock.imagesAllowed` | Comma-separated list of allowed Rock images. Empty value means that any images can be declared in the pod specifications.  | `""` |
| `opal.rock.specs[0].id` | Rock server profile identifier | `default` |
| `opal.rock.specs[0].type` | Rock server type | `rock` |
| `opal.rock.specs[0].description` | Rock server description | - |
| `opal.rock.specs[0].enabled` | Enable this Rock specification | `true` |
| `opal.rock.specs[0].namespace` | Namespace in which pod is to be created. Empty means same as Opal's. | - |
| `opal.rock.specs[0].nodeName` | Name of the node in which pod is to be created. | - |
| `opal.rock.specs[0].labels[0].key` | Pod label key | - |
| `opal.rock.specs[0].labels[0].value` | Pod label value | - |
| `opal.rock.specs[0].nodeSelector[0].key` | Node selection rule's key | - |
| `opal.rock.specs[0].nodeSelector[0].value` | Node selection rule's value | - |
| `opal.rock.specs[0].tolerations[0].key` | Pod [toleration](https://kubernetes.io/docs/concepts/scheduling-eviction/taint-and-toleration/) key | - |
| `opal.rock.specs[0].tolerations[0].operator` | Pod [toleration](https://kubernetes.io/docs/concepts/scheduling-eviction/taint-and-toleration/) operator | - |
| `opal.rock.specs[0].tolerations[0].value` | Pod [toleration](https://kubernetes.io/docs/concepts/scheduling-eviction/taint-and-toleration/) value | - |
| `opal.rock.specs[0].tolerations[0].effect` | Pod [toleration](https://kubernetes.io/docs/concepts/scheduling-eviction/taint-and-toleration/) effect | - |
| `opal.rock.specs[0].tolerations[0].tolerationSeconds` | Pod [toleration](https://kubernetes.io/docs/concepts/scheduling-eviction/taint-and-toleration/) seconds | - |
| `opal.rock.specs[0].container.name` | Pod name prefix | `rock-default` |
| `opal.rock.specs[0].container.image` | Rock container image | `datashield/rock-base:latest` |
| `opal.rock.specs[0].container.imagePullPolicy` | Image pull policy | `IfNotPresent` |
| `opal.rock.specs[0].container.imagePullSecret` | Image pull secret | - |
| `opal.rock.specs[0].container.port` | Rock container port | `8085` |
| `opal.rock.specs[0].container.resources.requests.cpu` | CPU request | `1000m` |
| `opal.rock.specs[0].container.resources.requests.memory` | Memory request | `500Mi` |
| `opal.rock.specs[0].container.resources.limits.cpu` | CPU limit | `2000m` |
| `opal.rock.specs[0].container.resources.limits.memory` | Memory limit | `1Gi` |

### Ingress Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `ingress.enabled` | Enable Ingress | `false` |
| `ingress.className` | Ingress class name | `"nginx"` |
| `ingress.annotations` | Ingress annotations | `{}` |
| `ingress.hosts[0].host` | Hostname | `opal.local` |
| `ingress.hosts[0].paths[0].path` | Path | `/` |
| `ingress.hosts[0].paths[0].pathType` | Path type | `Prefix` |
| `ingress.tls` | TLS configuration | `[]` |

## Examples

### Using Global Secret for All Credentials

```yaml
global:
  existingSecret: "opal-credentials"

# All components will use the global secret unless overridden
mongo:
  # Uses global.existingSecret
  enabled: false
  host: mongodb.example.com

postgres:
  data:
    # Uses global.existingSecret
    enabled: false
    host: postgres.example.com

opal:
  # Uses global.existingSecret for admin password
  adminPassword:
    # Will use global.existingSecret with key OPAL_ADMINISTRATOR_PASSWORD
    password: ""  # Not used when existingSecret is set
```

### Mixing Global and Component-Specific Secrets

```yaml
global:
  existingSecret: "shared-credentials"

mongo:
  # Override global secret for MongoDB only
  existingSecret: "mongodb-specific-secret"
  enabled: false
  host: mongodb.example.com

postgres:
  data:
    # Uses global.existingSecret
    enabled: false
    host: postgres.example.com

opal:
  adminPassword:
    # Override global secret for Opal admin password
    existingSecret: "opal-admin-secret"
```

### Using External MongoDB

```yaml
useMongo: true
mongo:
  enabled: false  # Disable internal MongoDB
  host: mongodb.example.com
  port: "27017"
  database:
    data: opal_data
    ids: opal_ids
  user: opal_user
  existingSecret: mongodb-credentials
```

### Using External PostgreSQL

```yaml
usePostgres:
  data: true
postgres:
  data:
    enabled: false  # Disable internal PostgreSQL
    host: postgres.example.com
    port: "5432"
    database: opal_db
    user: opal_user
    existingSecret: postgres-credentials
```

### Standalone Opal (No Database)

Opal 6.0.0 and later need no external database: the configuration lives in an embedded H2 database on the Opal volume, and a project can store its data in an H2 database of its own, on the same volume. Turning the default MongoDB off gives a fully featured single-pod Opal, with the same ServiceAccount, Role and Service:

```yaml
useMongo: false
mongo:
  enabled: false
```

Data import, views, R and DataSHIELD all work as usual. Since everything is on the volume, `opal.backup` covers the configuration and the data together; size `opal.pvcSize` for the data.

### Opal Configuration on PostgreSQL

Opal 6.0.0 and later keep the configuration (projects, permissions, users, registered databases, DataSHIELD profiles...) in an embedded H2 database under `data/config` on the Opal volume. `usePostgres.config` moves it to a PostgreSQL server, here an internally managed one with its own backup:

```yaml
usePostgres:
  config: true
postgres:
  config:
    enabled: true
    backup:
      enabled: true

opal:
  backup:
    enabled: true
```

Or an external one, with an existing, empty database and the credentials in a secret:

```yaml
usePostgres:
  config: true
postgres:
  config:
    enabled: false
    host: postgres.example.com
    port: "5432"
    database: opal_config
    # kubectl create secret generic postgres-config-credentials \
    #   --from-literal=POSTGRESCONFIG_DATABASE=opal_config \
    #   --from-literal=POSTGRESCONFIG_USER=opal \
    #   --from-literal=POSTGRESCONFIG_PASSWORD=...
    existingSecret: postgres-config-credentials
```

The Opal image writes the connection to `conf/opal-config.properties` at every start and waits for the port to answer before starting Opal, so an internal server coming up at the same time is fine. Two things to know:

- **Decide before the first start.** Opal writes its configuration to whatever database is configured at that moment. Turning `usePostgres.config` on for a release that already has a configuration on its volume gives an Opal with an empty configuration: no administrator password set, no databases registered, no projects. The first-run markers on the volume are not reset, so the first-run setup does not run again either.
- **Back it up together with the Opal volume.** On PostgreSQL the configuration is in the server, while the secret key that salts its user passwords and encrypts its stored credentials is still in `data/opal-config.xml` on the volume: a restore needs `postgres.config.backup` and `opal.backup` from the same moment.

The data and IDs databases (`useMongo`, `usePostgres.data`, `usePostgres.ids`) are unchanged: they hold the data and the identifiers, and are registered in the configuration through Opal's REST API on the first run.

### Enabling Backups

```yaml
mongo:
  backup:
    enabled: true
    schedule: "0 2 * * *"  # Daily at 2 AM
    pvcSize: 5Gi

postgres:
  data:
    backup:
      enabled: true
      schedule: "0 3 * * *"  # Daily at 3 AM
      pvcSize: 10Gi

opal:
  backup:
    enabled: true
    schedule: "0 4 * * *"  # Daily at 4 AM
    pvcSize: 2Gi
```

### Exporting to OpenTelemetry

The DataSHIELD stream carries the submitted R expressions, the usernames and the client addresses: it is the security audit trail, and unlike `datashield.log` it leaves the pod. Point it at a collector inside your trust boundary, over `https://`, with the token in a secret:

```yaml
opal:
  otel:
    enabled: true
    endpoint: "https://collector.example.org:4318"
    resourceAttributes: "deployment.environment=production,service.namespace=my-node"
    # kubectl create secret generic otel-credentials \
    #   --from-literal=OTEL_EXPORTER_OTLP_HEADERS='Authorization=Bearer%20...'
    existingSecret: otel-credentials
    # kubectl create secret generic otel-tls --from-file=ca.crt=ca.pem
    tls:
      existingSecret: otel-tls
```

A plaintext `http://` endpoint is only defensible on localhost, i.e. against a collector sidecar in the Opal pod. Any `OTEL_` variable the chart does not model goes through `opal.extraEnv`:

```yaml
opal:
  extraEnv:
    - name: OTEL_EXPORTER_OTLP_TRACES_ENDPOINT
      value: "https://tempo.example.org:4318/v1/traces"
```

What arrives at the collector: the audit records on scope `datashield.user` with the `ds_*` fields under their OpenTelemetry names (`datashield.session.id`, `datashield.action`, `datashield.script`, `enduser.id`, `client.address`); one trace per DataSHIELD session, rooted on a `datashield.session` span with the operations underneath it and a refused script as a `datashield.parse` span in status `ERROR`; and the `datashield.operation.count`, `datashield.operation.duration`, `datashield.session.active` and `datashield.quota.rejection` metrics. Opal prints `OpenTelemetry export enabled.` at startup when it picks the endpoint up.

**Upgrading a release from a 5.x chart.** Opal seeds `conf/` into the PVC on the first run only, so a volume created by Opal 5 keeps a `logback.xml` with no OpenTelemetry appenders in it: enable the export on such a release and it sends its traces and metrics and not one log record. Opal says so at startup:

```
OpenTelemetry export enabled.
WARNING: conf/logback.xml declares no OpenTelemetry appender, so no log record will be exported ...
```

If you never edited that file, replace it with the image's copy:

```
kubectl exec opal-0 -- cp /usr/share/opal/conf/logback.xml /srv/conf/logback.xml
kubectl rollout restart statefulset/opal
```

Otherwise merge the `otel`, `otelrest`, `otelraw` and `otelds` appenders, and the `appender-ref` entries that use them, from the image's file into yours.

### Custom Storage Classes

```yaml
global:
  storageClassName: "fast-ssd"

# Or per component
mongo:
  pvcSize: 2Gi
  backup:
    pvcSize: 5Gi

postgres:
  data:
    pvcSize: 5Gi
    backup:
      pvcSize: 10Gi
```

### Opal Service & Scheduling

Note: Opal is deployed as a single-pod StatefulSet; replica-spreading settings (anti-affinity, topology spread) do not apply. Use nodeSelector/tolerations to steer placement and security contexts to harden the pod.

```yaml
opal:
  service:
    type: NodePort
    annotations:
      prometheus.io/scrape: "true"
      prometheus.io/port: "8080"

  priorityClassName: "high-priority"

  nodeSelector:
    kubernetes.io/os: linux
    node-type: general-purpose

  tolerations:
    - key: "dedicated"
      operator: "Equal"
      value: "opal"
      effect: "NoSchedule"

  podSecurityContext:
    runAsUser: 1000
    runAsGroup: 1000
    fsGroup: 1000

  securityContext:
    readOnlyRootFilesystem: true
    allowPrivilegeEscalation: false
    capabilities:
      drop: ["ALL"]
```

### Rock Pod Configuration with Labels, Node Selection and Tolerations

```yaml
opal:
  rock:
    # Allow only specific Rock images
    imagesAllowed: "datashield/rock-base:latest,datashield/rock-demodata:latest"
    specs:
      - id: default
        type: rock
        description: "Production Rock server for data analysis"
        enabled: true
        # Target specific namespace (optional)
        namespace: "rock-servers"
        # Target specific node (optional)
        nodeName: "worker-node-1"
        # Add custom labels to Rock pods
        labels:
          - key: "environment"
            value: "production"
          - key: "team"
            value: "datascience"
          - key: "cost-center"
            value: "research"
        # Select nodes with specific labels
        nodeSelector:
          - key: "node-type"
            value: "compute-optimized"
          - key: "storage"
            value: "ssd"
        # Allow pods on tainted nodes
        tolerations:
          - key: "dedicated"
            operator: "Equal"
            value: "research"
            effect: "NoSchedule"
          - key: "gpu"
            operator: "Exists"
            effect: "NoExecute"
            tolerationSeconds: 3600
        container:
          name: rock-production
          image: datashield/rock-base:latest
          imagePullPolicy: IfNotPresent
          imagePullSecret: "private-registry-secret"
          port: 8085
          resources:
            requests:
              cpu: 2000m
              memory: 1Gi
            limits:
              cpu: 4000m
              memory: 4Gi
      
      # Additional Rock specification for development
      - id: development
        type: rock
        description: "Development Rock server"
        enabled: true
        labels:
          - key: "environment"
            value: "development"
        nodeSelector:
          - key: "node-type"
            value: "general-purpose"
        tolerations:
          - key: "development"
            operator: "Equal"
            value: "true"
            effect: "NoSchedule"
        container:
          name: rock-dev
          image: datashield/rock-demodata:latest
          imagePullPolicy: Always
          port: 8085
          resources:
            requests:
              cpu: 500m
              memory: 512Mi
            limits:
              cpu: 1000m
              memory: 1Gi
```

### Rock Pod Configuration for GPU Workloads

```yaml
opal:
  rock:
    specs:
      - id: gpu-enabled
        type: rock
        description: "GPU-accelerated Rock server for ML workloads"
        enabled: true
        # Target GPU nodes
        nodeSelector:
          - key: "accelerator"
            value: "nvidia-tesla-v100"
        # Tolerate GPU node taints
        tolerations:
          - key: "nvidia.com/gpu"
            operator: "Exists"
            effect: "NoSchedule"
        # Add GPU-specific labels
        labels:
          - key: "workload-type"
            value: "gpu-compute"
          - key: "gpu-memory"
            value: "16gb"
        container:
          name: rock-gpu
          image: datashield/rock-gpu:latest
          resources:
            requests:
              cpu: 4000m
              memory: 8Gi
              nvidia.com/gpu: 1
            limits:
              cpu: 8000m
              memory: 16Gi
              nvidia.com/gpu: 1
```

